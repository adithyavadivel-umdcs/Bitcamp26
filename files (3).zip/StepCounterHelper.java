package com.example.bitcamp26.core.util;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/**
 * Wraps Android SensorManager to count steps during a match.
 *
 * Usage:
 *   StepCounterHelper helper = new StepCounterHelper(context);
 *   helper.start();                        // call when match begins
 *   long steps = helper.getMatchSteps();   // poll anytime during match
 *   helper.stop();                         // call when match ends
 */
public class StepCounterHelper implements SensorEventListener {

    public interface StepUpdateListener {
        void onStepsUpdated(long matchSteps);
    }

    private final SensorManager sensorManager;
    private Sensor stepCounterSensor;

    private long stepsAtMatchStart = -1;
    private long currentStepCount  = 0;
    private boolean running         = false;

    private StepUpdateListener listener;

    public StepCounterHelper(Context context) {
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        }
    }

    public void setListener(StepUpdateListener listener) {
        this.listener = listener;
    }

    /** Returns true if the device has a step counter sensor. */
    public boolean isAvailable() {
        return stepCounterSensor != null;
    }

    /** Start counting steps. Call at match start. */
    public void start() {
        if (!isAvailable() || running) return;
        stepsAtMatchStart = -1;
        running = true;
        sensorManager.registerListener(this, stepCounterSensor,
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    /** Stop counting steps. Call at match end or when fragment is destroyed. */
    public void stop() {
        if (!running) return;
        running = false;
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    /** Returns steps walked since start() was called. */
    public long getMatchSteps() {
        if (stepsAtMatchStart < 0) return 0;
        return Math.max(0, currentStepCount - stepsAtMatchStart);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_STEP_COUNTER) return;

        long totalSteps = (long) event.values[0];

        // First reading — record baseline
        if (stepsAtMatchStart < 0) {
            stepsAtMatchStart = totalSteps;
        }

        currentStepCount = totalSteps;

        if (listener != null) {
            listener.onStepsUpdated(getMatchSteps());
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not needed
    }
}
