# Bitcamp26 — Deploy Checklist

## 1. Firebase Console Setup (do this NOW)

Go to https://console.firebase.google.com → project: bitcamp26

### Enable Anonymous Authentication
- Authentication → Sign-in method → Anonymous → Enable

### Enable Realtime Database
- Realtime Database → Create database
- Choose "Start in test mode" for the hackathon
- Region: us-central1
- Confirm the URL is: https://bitcamp26-default-rtdb.firebaseio.com

### Deploy Database Rules
From repo root:
```
firebase deploy --only database
```

## 2. Deploy Cloud Functions

From repo root:
```
cd functions
npm install
cd ..
firebase deploy --only functions
```

If you get a billing error, enable the Blaze (pay-as-you-go) plan on the Firebase console.
Hackathon usage will be well within the free tier limits.

## 3. Maps API Key

Go to https://console.cloud.google.com → project: bitcamp26
- APIs & Services → Enable "Maps SDK for Android"
- Credentials → Create API Key
- Add it to local.properties (create this file if it doesn't exist):

```
MAPS_API_KEY=YOUR_KEY_HERE
```

Make sure app/build.gradle.kts reads it:
```kotlin
android {
    defaultConfig {
        manifestPlaceholders["MAPS_API_KEY"] = project.findProperty("MAPS_API_KEY") ?: ""
    }
}
```

## 4. google-services.json

Place the updated google-services.json (from outputs/) into:
```
app/google-services.json
```

The key addition is the firebase_url field:
```
"firebase_url": "https://bitcamp26-default-rtdb.firebaseio.com"
```

## 5. Verify Firebase Connection

Run the app on a physical device.
- Check Logcat for "Firebase" — should see successful auth
- In Firebase Console → Realtime Database, you should see data appear
  when a lobby is created

## 6. Two-Device Test (do before demo)

Device A: Create lobby → share invite code
Device B: Join lobby with code
Both: Hit Ready
Device A (host): Hit Start
Verify: Both devices transition to match screen, location dots appear

## 7. Demo Script (60 seconds)

1. Open app on both phones
2. Person A creates game — show invite code on screen
3. Person B types code and joins — both names appear in lobby
4. Both hit Ready — Start button enables
5. Hit Start — head start countdown appears
6. Walk a few steps — show location updating on map
7. Person B (seeker) types Person A's catch code — "Caught!" toast
8. Game ends — results screen shows winner and steps
```
